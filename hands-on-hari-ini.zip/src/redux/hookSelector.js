export const hookSelector=state=>{
    return state.hookReducer.number
}